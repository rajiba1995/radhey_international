<?php

namespace App\Http\Livewire;

use Livewire\Component;

class RTL extends Component
{
    public function render()
    {
        return view('livewire.r-t-l');
    }
}
