<?php

namespace App\Http\Livewire\Staff;

use Livewire\Component;

class StaffTaskAdd extends Component
{
    public function render()
    {
        return view('livewire.staff.staff-task-add');
    }
}
