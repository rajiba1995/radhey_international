<div>
    <h4>Supplier Details</h4>
    <div class="row">
        <div class="col-12">
            <div class="card my-4">
                <div class="table-responsive p-0">
                    <div class="card-header">
                        <h3><?php echo e($supplier->name); ?></h3>
                    </div>
                    <div class="card-body">
                        <p><strong>Email:</strong> <?php echo e($supplier->email); ?></p>
                        <p><strong>Mobile:</strong> <?php echo e($supplier->mobile); ?></p>
                        <p><strong>WhatsApp Number:</strong> 
                            <?php echo e($supplier->is_wa_same ? $supplier->mobile : $supplier->whatsapp_no); ?>

                        </p>
                        <p><strong>GST Number:</strong> <?php echo e($supplier->gst_number); ?></p>
                        <p><strong>Credit Limit:</strong> <?php echo e($supplier->credit_limit); ?></p>
                        <p><strong>Credit Days:</strong> <?php echo e($supplier->credit_days); ?></p>
                        <p><strong>Status:</strong> <?php echo e($supplier->status == 1 ? 'Active' : 'Inactive'); ?></p>

                        <!-- Billing Address Details -->
                        <h6>Billing Address:</h6>
                        <p><strong>Address:</strong> <?php echo e($supplier->billing_address); ?></p>
                        <p><strong>Landmark:</strong> <?php echo e($supplier->billing_landmark); ?></p>
                        <p><strong>City:</strong> <?php echo e($supplier->billing_city); ?></p>
                        <p><strong>State:</strong> <?php echo e($supplier->billing_state); ?></p>
                        <p><strong>Country:</strong> <?php echo e($supplier->billing_country); ?></p>
                        <p><strong>Pin Code:</strong> <?php echo e($supplier->billing_pin); ?></p>

                        <!-- Shipping Address Details -->
                        <h6>Shipping Address:</h6>
                        <!--[if BLOCK]><![endif]--><?php if($supplier->is_billing_shipping_same): ?>
                            <p>Same as Billing Address</p>
                        <?php else: ?>
                            <p><strong>Address:</strong> <?php echo e($supplier->shipping_address); ?></p>
                            <p><strong>Landmark:</strong> <?php echo e($supplier->shipping_landmark); ?></p>
                            <p><strong>City:</strong> <?php echo e($supplier->shipping_city); ?></p>
                            <p><strong>State:</strong> <?php echo e($supplier->shipping_state); ?></p>
                            <p><strong>Country:</strong> <?php echo e($supplier->shipping_country); ?></p>
                            <p><strong>Pin Code:</strong> <?php echo e($supplier->shipping_pin); ?></p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!-- GST Certificate -->
                        <!--[if BLOCK]><![endif]--><?php if($supplier->gst_file): ?>
                            <h6>GST Certificate:</h6>
                            <img src="<?php echo e(asset('storage/' . $supplier->gst_file)); ?>" alt="GST Certificate" class="img-thumbnail" width="200">
                        <?php else: ?>
                            <p>No GST certificate uploaded.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-primary mt-3">Back to List</a>
</div>
<?php /**PATH C:\xampp\htdocs\radhey_international_crm\resources\views/livewire/supplier/supplier-details.blade.php ENDPATH**/ ?>