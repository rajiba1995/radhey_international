<aside
    class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark"
    id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
            <a class="navbar-brand m-0 d-flex text-wrap align-items-center" href=" <?php echo e(route('dashboard')); ?> ">
                <img src="<?php echo e(asset('assets')); ?>/img/logo.png" class="navbar-brand-img h-100" alt="main_logo">
                
            </a>
    </div>
    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto  max-height-vh-100" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            
            
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(Route::currentRouteName() == $module['route'] ? ' active bg-gradient-primary' : ''); ?>"
                    href="<?php echo e(route($module['route'])); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10"><?php echo e($module['icon']); ?></i>
                    </div>
                    <span class="nav-link-text ms-1"><?php echo e($module['name']); ?></span>
                </a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Master Modules</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(in_array(Route::currentRouteName(), ['admin.categories', 'admin.subcategories', 'product.view','product.add','product.update']) ? 'active bg-gradient-primary' : ''); ?>"
                    href="#productManagementSubmenu" data-bs-toggle="collapse" aria-expanded="<?php echo e(in_array(Route::currentRouteName(), ['admin.categories', 'admin.subcategories', 'product.view','product.add','product.update']) ? 'true' : 'false'); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">store</i>
                    </div>
                    <span class="nav-link-text ms-1">Product Management</span>
                </a>
            </li>
        
            <!-- Submenu -->
            <ul id="productManagementSubmenu" class="collapse list-unstyled ms-4 <?php echo e(in_array(Route::currentRouteName(), ['admin.categories', 'admin.subcategories', 'product.view','product.add','product.update']) ? 'show' : ''); ?>">  
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'product.view' ? 'active bg-gradient-primary' : ''); ?>"
                        href="<?php echo e(route('product.view')); ?>">
                         Products
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'admin.categories' ? 'active bg-gradient-primary' : ''); ?>"
                        href="<?php echo e(route('admin.categories')); ?>">
                        Categories
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'admin.subcategories' ? 'active bg-gradient-primary' : ''); ?>"
                        href="<?php echo e(route('admin.subcategories')); ?>">
                        Sub Categories
                    </a>
                </li>
            </ul>
            <li class="nav-item">
                <a class="nav-link text-white <?php echo e(in_array(Route::currentRouteName(), ['staff.designation']) ? 'active bg-gradient-primary' : ''); ?>"
                    href="#StaffManagementSubmenu" data-bs-toggle="collapse" aria-expanded="<?php echo e(in_array(Route::currentRouteName(), ['staff.designation']) ? 'true' : 'false'); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Staff Management</span>
                </a>
            </li>
        
            <!-- Submenu -->
            <ul id="StaffManagementSubmenu" class="collapse list-unstyled ms-4 <?php echo e(in_array(Route::currentRouteName(), ['staff.designation']) ? 'show' : ''); ?>">
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(Route::currentRouteName() == 'staff.designation' ? 'active bg-gradient-primary' : ''); ?>"
                        href="<?php echo e(route('staff.designation')); ?>">
                        Designation
                    </a>
                </li>
                
            </ul>
        </ul>
    </div>
    <div class="sidenav-footer position-absolute w-100 bottom-0 ">
        <div class="mx-3">
            <a class="btn bg-gradient-secondary w-100" href="javascript:;">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('auth.logout', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3017518082-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </a>
        </div>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\radhey_international_crm\resources\views/livewire/navigation-menu.blade.php ENDPATH**/ ?>