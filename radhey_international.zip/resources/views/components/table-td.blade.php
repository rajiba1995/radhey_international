<td {{ $attributes->merge() }}>
    {{ $slot }}
</td>