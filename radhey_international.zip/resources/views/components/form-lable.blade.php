<label {{ $attributes->merge(['class' => 'date_label']) }}>
    {{ $slot }}
</label>