<div class="container">
    <section class="admin__title">
        <h5>Edit Invoice</h5>
    </section>
    <section>
        <ul class="breadcrumb_menu">
            <li>Invoice</li>
            <li>{{$invoice->invoice_no}}</li>
            <li >Edit</li>
          </ul>
        <ul class="breadcrumb_menu">
            <li>Packing Slip</li>
            <li>{{$invoice->packing->slipno}}</li>
            <li >Edit</li>
          </ul>
        
    </section>
    <div class="card mb-3 p-3" style="background-color:rgb(249, 252, 252)">
        hey
    </div>
</div>
