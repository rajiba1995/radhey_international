<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CatalogueTitle extends Model
{
    protected $table = 'catalogue_titles';
    
}
