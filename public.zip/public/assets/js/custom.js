
    // // Listen for Livewire's event when the message is rendered or updated
    // Livewire.on('flashMessage', () => {
    //     setTimeout(() => {
    //         const flashMessage = document.getElementById('flashMessage');
    //         if (flashMessage) {
    //             flashMessage.style.transition = 'opacity 1s';
    //             flashMessage.style.opacity = 0;
    //             setTimeout(() => {
    //                 flashMessage.style.display = 'none';
    //             }, 1000); // Make sure to hide after fade-out
    //         }
    //     }, 3000); // 3 seconds delay to fade out
    // });
    